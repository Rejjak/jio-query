var getClasses = require('./lib/ClassLoader');

exports.loadMethods = function(conObj) {
    var functionalities = getClasses.loadClass('QueryBuilder');
    if (typeof conObj !== 'string' && conObj.config !== undefined) {
       if((conObj.config.host).length){
            return functionalities.pushDbObject(conObj);
       }else{
            throw new Error('Cannot find database object');
       }
    }else{
        throw new Error('Cannot find database object');
    }
};
